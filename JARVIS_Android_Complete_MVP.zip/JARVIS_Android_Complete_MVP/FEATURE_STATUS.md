# Feature status

| Feature | Status |
|---|---|
| Particle orb UI | Implemented |
| Hinglish speech locale / TTS locale | Implemented (voice availability depends on device) |
| Push-to-talk | Implemented |
| AI chat | Implemented when backend is configured |
| Open installed apps by launcher label | Implemented |
| Lock screen | Implemented after Device Admin opt-in |
| Capture notification previews | Implemented after Notification Access opt-in |
| Read latest captured notification | Implemented |
| Hey JARVIS always-on wake word | Not implemented |
| Gmail OAuth inbox integration | Not implemented |
| WhatsApp message history / auto-send | Not implemented |
| Music streaming account control | Not implemented |
| Live market feeds | Not implemented |
| Trading recommendations based on live data | Not implemented |
| Automated broker orders | Not implemented |
