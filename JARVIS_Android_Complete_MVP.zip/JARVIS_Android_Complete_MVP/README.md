# JARVIS Android — Complete MVP scaffold

Native Android starter built with Kotlin + Jetpack Compose, using the user's particle-sphere reference as the UI inspiration.

## What works in this MVP
- Animated particle-network sphere UI.
- Tap-to-talk speech recognition (Hindi India locale) and Android TTS (Hindi voice if installed).
- AI conversation through the FastAPI backend once the backend URL and API key are configured.
- Launches installed apps by matching their launcher label.
- Opens Android Settings.
- Screen lock after the user explicitly enables JARVIS Device Administrator.
- Notification Listener service after the user explicitly enables Notification Access.
- Reads back the latest notification captured by that listener.
- Hinglish system instructions in the AI backend.

## Setup
1. Install Android Studio and Android SDK 35.
2. Open this folder in Android Studio and sync Gradle.
3. Run the app on an Android 8.0+ device.
4. Grant microphone permission.
5. Start the backend using `backend/README.md`.
6. In JARVIS, open Settings and enter the backend URL:
   - Emulator: `http://10.0.2.2:8000`
   - Physical device: `http://YOUR_COMPUTER_LAN_IP:8000`
7. Enable Notification Access if you want JARVIS to capture notifications.
8. Enable Device Administrator only if you want the screen-lock command.

## Important: what is not included / needs your credentials or provider
- Always-on "Hey JARVIS": not shipped enabled. Android background microphone restrictions and wake-word provider credentials/model are required. The current mic button is push-to-talk. Do not expect hands-free wake phrase yet.
- Gmail inbox sync: requires Google OAuth consent and Gmail API integration. Notification access is not Gmail account access.
- WhatsApp history or silent sending: not supported. Notification access can capture notification previews only; WhatsApp may hide message content. Use official share/deep-link workflows and confirm before sending.
- Live NSE/BSE, forex and crypto quotes: no market-data vendor configured. A proper feed requires a selected provider/API plan and symbol mapping. The AI is instructed not to invent live prices.
- Broker integration or automatic trade execution: deliberately not included. No trading credentials should be placed in this app. Analysis must not be represented as guaranteed financial advice.
- Full always-on background operation: depends on Android version, manufacturer battery policies and foreground-service eligibility.

## Safety and privacy
- Notification content may contain private information. It is stored locally as the latest notification in app-private preferences.
- Do not use a public, unauthenticated backend. Add HTTPS and authentication before remote deployment.
- API key belongs on the backend, never in the APK.
- High-impact actions (payments, deleting data, sending messages, trading) should require user confirmation.

## Build status
This project has been generated but has not been compiled or tested on the user's specific phone. Validate Gradle sync and run on-device before relying on it.
