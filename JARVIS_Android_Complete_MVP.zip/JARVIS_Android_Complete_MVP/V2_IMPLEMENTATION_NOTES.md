# JARVIS V2 implementation notes

## Added in this version
- Hindi (India) speech recognition locale and Hindi TTS voice selection (device voice availability varies).
- Notification Listener Service. User must manually enable JARVIS in Android Notification Access settings.
- Latest notification is stored locally in app-private preferences. This starter does not yet expose a notification inbox UI or send/read WhatsApp/Gmail account history.
- FastAPI AI gateway sample. The API key remains on the backend, not in the APK.
- Internet permission and backend setup instructions.

## Still not a finished feature
- The Android app does not yet call the sample `/chat` endpoint from its UI. Connect an AI client and add a backend URL setting before AI chat works end-to-end.
- The notification listener is permission-gated and currently stores only the latest notification. It does not bypass app privacy controls.
- Live NSE/BSE, forex and crypto market data is not connected. A reliable market data provider is needed before showing prices or analysis. Never treat demo values as live quotes.
- "Hey JARVIS" always-on wake-word detection is not included yet. It requires a dedicated on-device wake-word SDK/model (for example, a user-configured Picovoice Porcupine keyword model and access key), plus a microphone foreground service, persistent notification, battery testing and Android-version/OEM testing. Android does not permit an ordinary app to silently keep the microphone open indefinitely.
- No automated trade execution is included. Trading outputs must remain informational unless a separately authorized broker integration is built with strict confirmations and risk limits.

## Next engineering tasks
1. Add a configurable backend URL and AI client call from the chat flow.
2. Add a notification inbox screen with app/package, timestamp and user-controlled deletion.
3. Integrate a wake-word provider and ship no hard-coded provider secret.
4. Select a market data provider and implement timestamped quote/chart APIs; clearly label delayed quotes.
5. Add test coverage and verify on the user's exact phone model.
