package com.example.jarvis

import android.app.admin.DeviceAdminReceiver

class JarvisAdminReceiver : DeviceAdminReceiver()
