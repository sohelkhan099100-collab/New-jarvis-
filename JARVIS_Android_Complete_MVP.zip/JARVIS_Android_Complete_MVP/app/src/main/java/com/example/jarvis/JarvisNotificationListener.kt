package com.example.jarvis

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Reads notification content only after the user explicitly enables
 * JARVIS in Android's Notification Access settings.
 * Notification contents are stored locally on this device.
 */
class JarvisNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val item = "${sbn.packageName}|$title|$text|${sbn.postTime}"
        getSharedPreferences("jarvis_notifications", MODE_PRIVATE)
            .edit()
            .putString("latest_notification", item)
            .apply()
    }
}
