package com.example.jarvis

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.*
import kotlin.random.Random

private val Bg = Color(0xFF030507)
private val Glow = Color(0xFFEAF7FF)
private val Muted = Color(0xFF8FA6B8)
private enum class JarvisState { IDLE, LISTENING, THINKING, SPEAKING, EXECUTING }

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var onRecognized: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent { JarvisScreen(
            startListening = { callback -> listen(callback) },
            speak = { text -> speak(text) },
            askAi = { baseUrl, prompt, callback -> askAi(baseUrl, prompt, callback) }
        ) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun askAi(baseUrl: String, prompt: String, callback: (String) -> Unit) {
        thread {
            var connection: HttpURLConnection? = null
            try {
                val url = URL(baseUrl.trimEnd('/') + "/chat")
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 12000
                    readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val body = JSONObject().put("message", prompt).toString()
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
                val raw = stream.bufferedReader().use { it.readText() }
                val reply = JSONObject(raw).optString("reply", "AI server ne empty response diya.")
                runOnUiThread { callback(reply) }
            } catch (e: Exception) {
                runOnUiThread {
                    callback("AI server se connect nahi ho paya. Backend URL, server status aur internet check karein. Detail: ${e.javaClass.simpleName}")
                }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun listen(callback: (String) -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            callback("Microphone permission is required. Please grant it and try again.")
            return
        }
        val recognizer = speechRecognizer ?: run {
            callback("Speech recognition is not available on this device.")
            return
        }
        onRecognized = callback
        recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { callback("I couldn't hear that clearly. Please try again.") }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                callback(spoken ?: "I didn't catch that.")
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        recognizer.startListening(intent)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisScreen(
    startListening: ((String) -> Unit) -> Unit,
    speak: (String) -> Unit,
    askAi: (String, String, (String) -> Unit) -> Unit
) {
    val context = LocalContext.current
    var state by remember { mutableStateOf(JarvisState.IDLE) }
    var status by remember { mutableStateOf("SYSTEM ONLINE") }
    var lastCommand by remember { mutableStateOf("At your service.") }
    var response by remember { mutableStateOf("Hello. I am JARVIS. How may I assist you?") }
    var showHelp by remember { mutableStateOf(false) }
    var backendUrl by remember { mutableStateOf("http://10.0.2.2:8000") }
    var showSettings by remember { mutableStateOf(false) }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            state = JarvisState.LISTENING
            status = "LISTENING"
            startListening { phrase ->
                lastCommand = phrase
                state = JarvisState.THINKING
                status = "PROCESSING"
                val result = handleCommand(context, phrase)
                if (result.first) {
                    response = result.second
                    state = JarvisState.EXECUTING
                    status = "EXECUTING"
                    speak(response)
                    state = JarvisState.IDLE
                    status = "SYSTEM ONLINE"
                } else {
                    response = "Soch raha hoon..."
                    askAi(backendUrl, phrase) { answer ->
                        response = answer
                        state = JarvisState.SPEAKING
                        status = "RESPONDING"
                        speak(answer)
                        state = JarvisState.IDLE
                        status = "SYSTEM ONLINE"
                    }
                }
            }
        } else {
            response = "Microphone permission was not granted."
            speak(response)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Color(0xFF0A1017), primary = Glow,
        onBackground = Glow, onSurface = Glow
    )) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("J.A.R.V.I.S", color = Glow, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 4.sp)
                        Text("PERSONAL AI SYSTEM", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                    }
                    IconButton(onClick = { showHelp = true }) {
                        Icon(Icons.Default.HelpOutline, contentDescription = "Help", tint = Muted)
                    }
                    Icon(Icons.Default.Wifi, contentDescription = "Online", tint = Color(0xFF8EE6C0))
                }

                Spacer(Modifier.height(12.dp))
                Text(status, color = if (state == JarvisState.LISTENING) Color(0xFF9BE7FF) else Muted,
                    fontSize = 10.sp, letterSpacing = 3.sp)
                Spacer(Modifier.weight(0.35f))

                ParticleOrb(state, Modifier.fillMaxWidth().height(310.dp))

                Spacer(Modifier.height(12.dp))
                Text(
                    when (state) {
                        JarvisState.LISTENING -> "I'M LISTENING"
                        JarvisState.THINKING -> "PROCESSING"
                        JarvisState.SPEAKING -> "SPEAKING"
                        JarvisState.EXECUTING -> "EXECUTING TASK"
                        else -> "AT YOUR SERVICE"
                    },
                    color = Glow, fontSize = 12.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(10.dp))
                Text(response, color = Color(0xFFB9C9D6), fontSize = 13.sp,
                    textAlign = TextAlign.Center, lineHeight = 19.sp,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 42.dp))
                Spacer(Modifier.height(8.dp))
                Text("LAST COMMAND  ·  $lastCommand", color = Muted, fontSize = 9.sp,
                    textAlign = TextAlign.Center, maxLines = 2)
                Spacer(Modifier.weight(0.4f))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    QuickAction("APPS", Icons.Default.Apps, Modifier.weight(1f)) {
                        response = "Try saying: open YouTube, open WhatsApp, or open Settings."
                        speak(response)
                    }
                    QuickAction("MARKET", Icons.Default.ShowChart, Modifier.weight(1f)) {
                        response = "Market module is planned. Live prices and analysis need a market-data provider."
                        speak(response)
                    }
                    QuickAction("TASKS", Icons.Default.CheckCircleOutline, Modifier.weight(1f)) {
                        response = "Task automation module is ready for the next development stage."
                        speak(response)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Tune, contentDescription = "Settings", tint = Muted)
                    }
                    Box(
                        Modifier.size(76.dp).background(Color(0xFF15222D), CircleShape)
                            .clickable {
                                state = JarvisState.LISTENING
                                status = "LISTENING"
                                micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "Talk to JARVIS",
                            tint = Glow, modifier = Modifier.size(32.dp))
                    }
                    IconButton(onClick = {
                        response = "JARVIS is online. Tap the microphone to speak."
                        speak(response)
                    }) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "Speak", tint = Muted)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("TAP THE MICROPHONE TO TALK", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
            }

            if (showSettings) {
                AlertDialog(
                    onDismissRequest = { showSettings = false },
                    title = { Text("AI backend settings") },
                    text = {
                        Column {
                            Text("Backend URL (emulator default: http://10.0.2.2:8000)")
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = backendUrl,
                                onValueChange = { backendUrl = it },
                                singleLine = true,
                                label = { Text("Backend URL") }
                            )
                            Text("Physical phone par apne computer ka LAN IP use karein, e.g. http://192.168.x.x:8000. Local HTTP is for development only; use HTTPS for deployed servers.",
                                color = Muted, fontSize = 11.sp)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showSettings = false }) { Text("SAVE") }
                    },
                    containerColor = Color(0xFF101923),
                    titleContentColor = Glow,
                    textContentColor = Color(0xFFB9C9D6)
                )
            }

            if (showHelp) {
                AlertDialog(
                    onDismissRequest = { showHelp = false },
                    title = { Text("JARVIS command guide") },
                    text = { Text(
                        "Try these commands:\n\n• Open YouTube\n• Open WhatsApp\n• Open Settings\n• Lock my phone\n• What can you do?\n\nVoice recognition uses your device speech service. General questions go to your configured AI backend. App launching, screen lock and notification-access settings are available. Always-on wake phrase, direct email sync and live market feeds need additional setup."
                    ) },
                    confirmButton = {
                        TextButton(onClick = { showHelp = false }) { Text("CLOSE") }
                    },
                    containerColor = Color(0xFF101923),
                    titleContentColor = Glow,
                    textContentColor = Color(0xFFB9C9D6)
                )
            }
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
                        modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.background(Color(0xFF0C141C), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(vertical = 13.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = Color(0xFFDCECF7), modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(7.dp))
        Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
    }
}

@Composable
private fun ParticleOrb(state: JarvisState, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "orb")
    val rotation by transition.animateFloat(
        initialValue = 0f, targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(
            durationMillis = if (state == JarvisState.THINKING) 4500 else 15000,
            easing = LinearEasing
        ), RepeatMode.Restart), label = "rotation"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.88f, targetValue = if (state == JarvisState.LISTENING) 1.15f else 1.02f,
        animationSpec = infiniteRepeatable(tween(1300), RepeatMode.Reverse), label = "pulse"
    )
    val nodes = remember {
        val random = Random(42)
        List(125) {
            val z = random.nextDouble(-1.0, 1.0)
            val a = random.nextDouble(0.0, 2.0 * PI)
            val r = sqrt(1.0 - z * z)
            Triple(r * cos(a), r * sin(a), z)
        }
    }
    Canvas(modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val radius = min(size.width, size.height) * 0.405f * pulse
        val projected = nodes.map { (x, y, z) ->
            val rx = x * cos(rotation) - z * sin(rotation)
            val rz = x * sin(rotation) + z * cos(rotation)
            val perspective = 1.0 / (1.0 + rz * 0.20)
            Offset((cx + rx * radius * perspective).toFloat(),
                (cy + y * radius * perspective).toFloat()) to rz
        }
        val alpha = when (state) {
            JarvisState.LISTENING -> 0.95f
            JarvisState.THINKING -> 0.82f
            JarvisState.SPEAKING -> 0.9f
            JarvisState.EXECUTING -> 0.78f
            else -> 0.62f
        }
        for (i in projected.indices) {
            for (j in i + 1 until projected.size) {
                val p1 = projected[i].first
                val p2 = projected[j].first
                val d = hypot(p1.x - p2.x, p1.y - p2.y)
                if (d < radius * 0.34f) {
                    drawLine(Glow.copy(alpha = alpha * (1f - d / (radius * 0.34f)) * 0.42f),
                        p1, p2, strokeWidth = 0.65f)
                }
            }
        }
        projected.forEachIndexed { index, pair ->
            val depthAlpha = (0.30f + ((pair.second + 1f) / 2f) * 0.70f) * alpha
            val pointRadius = if (index % 9 == 0) 2.2f else 1.15f
            drawCircle(Glow.copy(alpha = depthAlpha), pointRadius, pair.first)
            if (index % 13 == 0) {
                drawCircle(Glow.copy(alpha = depthAlpha * 0.16f), pointRadius * 4.0f, pair.first,
                    style = Stroke(width = 0.7f))
            }
        }
    }
}

private fun handleCommand(context: Context, raw: String): Pair<Boolean, String> {
    val command = raw.lowercase(Locale.getDefault()).trim()
    if (command.contains("what can you do") || command == "help") {
        return false to "I can open apps and settings, and I am being built to manage your daily tasks, messages, entertainment and market research."
    }
    if (command.contains("lock") && (command.contains("phone") || command.contains("mobile") || command.contains("screen"))) {
        val admin = ComponentName(context, JarvisAdminReceiver::class.java)
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (dpm.isAdminActive(admin)) {
            dpm.lockNow()
            return true to "Locking your phone."
        }
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Allow JARVIS to lock your screen when you ask.")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return true to "Please approve JARVIS device administrator access. Then ask me to lock your phone again."
    }
    if (command.startsWith("open ")) {
        val target = command.removePrefix("open ").trim()
        if ("settings" in target) {
            context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return true to "Settings khol raha hoon."
        }
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val matches = context.packageManager.queryIntentActivities(launcherIntent, 0)
        val match = matches.firstOrNull { info ->
            info.loadLabel(context.packageManager).toString().equals(target, ignoreCase = true)
        } ?: matches.firstOrNull { info ->
            info.loadLabel(context.packageManager).toString().contains(target, ignoreCase = true)
        }
        if (match != null) {
            val launch = context.packageManager.getLaunchIntentForPackage(match.activityInfo.packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                return true to "${match.loadLabel(context.packageManager)} open kar raha hoon."
            }
        }
        return false to "$target naam ka installed app nahi mila. App ka exact naam bolkar try karein."
    }
    if (command.contains("market") || command.contains("trading") || command.contains("stock")) {
        return false to "The trading intelligence module is not connected yet. We will add live market data, daily analysis, watchlists and risk-managed trade ideas in a later phase."
    }
    if (command.contains("read") && command.contains("notification")) {
        val saved = context.getSharedPreferences("jarvis_notifications", Context.MODE_PRIVATE)
            .getString("latest_notification", null)
        if (saved.isNullOrBlank()) return false to "Abhi koi saved notification nahi mila. Pehle Android Settings mein JARVIS Notification Access enable karein."
        val parts = saved.split("|", limit = 4)
        val app = parts.getOrNull(0) ?: "App"
        val title = parts.getOrNull(1) ?: ""
        val body = parts.getOrNull(2) ?: ""
        return true to "Latest notification from $app. $title. $body"
    }
    if (command.contains("notification") || command.contains("notifications")) {
        val intent = Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true to "Notification access settings khol raha hoon. JARVIS ko access allow karein."
    }
    if (command.contains("email") || command.contains("message") || command.contains("whatsapp")) {
        return false to "Communication integration is not connected yet. For now, I can open supported messaging and email apps."
    }
    return false to "I heard: $raw. My local command set is still growing. The next step is connecting the AI brain so I can answer general questions and plan multi-step tasks."
}
