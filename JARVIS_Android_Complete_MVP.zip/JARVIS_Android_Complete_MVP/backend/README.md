# JARVIS AI Gateway

## Run locally
Python 3.10+ recommended.

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell
# .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
```

Set your API key on the server only:

```bash
# macOS/Linux
export OPENAI_API_KEY="YOUR_API_KEY"
# Windows PowerShell
# $env:OPENAI_API_KEY="YOUR_API_KEY"
uvicorn main:app --host 0.0.0.0 --port 8000
```

Health check: `http://127.0.0.1:8000/health`

## Android connection
- Android emulator: `http://10.0.2.2:8000`
- Physical phone: use the computer's LAN IP and same Wi-Fi, e.g. `http://192.168.1.20:8000`
- Set the URL in JARVIS Settings (gear/tune icon).

This is a local development setup. Do not expose it to the public internet as-is. For deployment, use HTTPS, authentication, rate limits, request-size limits, secret management and firewall rules. Do not put API keys in the Android app.
