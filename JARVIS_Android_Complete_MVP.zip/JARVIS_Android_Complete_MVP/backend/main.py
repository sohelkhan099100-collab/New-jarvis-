import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from openai import OpenAI

app = FastAPI(title="JARVIS AI Gateway", version="1.0.0")

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8000)

@app.get("/health")
def health():
    return {"status": "ok", "ai_configured": bool(os.environ.get("OPENAI_API_KEY"))}

@app.post("/chat")
def chat(req: ChatRequest):
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(503, "AI backend is not configured: set OPENAI_API_KEY on the server")
    try:
        client = OpenAI(api_key=api_key)
        result = client.responses.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-4.1-mini"),
            instructions=(
                "You are JARVIS, a careful personal assistant for an Indian user. "
                "Reply naturally in Hinglish (Hindi mixed with English), unless asked otherwise. "
                "Be concise, useful and transparent. Never claim to have performed phone actions; "
                "the Android app performs those separately. Never invent live prices, market news, "
                "or data. For Indian equities, forex and crypto, explain uncertainty, timeframe, "
                "risk and invalidation. Give educational analysis, not guaranteed calls. "
                "Do not place trades or request broker passwords, OTPs or API secrets."
            ),
            input=req.message,
        )
        return {"reply": result.output_text}
    except Exception as exc:
        raise HTTPException(502, f"AI gateway error: {type(exc).__name__}")
